def winner(board):
    # Check rows and columns
    for i in range(3):
        if board[i][0] == board[i][1] == board[i][2] != ' ':
            return board[i][0]  # Row winner
        if board[0][i] == board[1][i] == board[2][i] != ' ':
            return board[0][i]  # Column winner

    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] != ' ':
        return board[0][0]  # Diagonal winner
    if board[0][2] == board[1][1] == board[2][0] != ' ':
        return board[0][2]  # Diagonal winner

    return None  # No winner

# Create a 3x3 tic-tac-toe board

tic_tac_toe_board = [
    ['3', '100', '8'],
    ['2', '3', '2'],
    [' 6', '3', '3']
]

# Check for a winner
winner = winner(tic_tac_toe_board)

# Output the result
if winner:
    print(f"The winner is: {winner}")
else:
    print("No winner yet.")
