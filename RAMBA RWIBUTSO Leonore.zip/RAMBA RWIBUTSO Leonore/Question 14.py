list_of_to_do = []
def add_task(task):
    list_of_to_do.append(task)
    print(f"Added task: '{task}'")

# Function to remove a task
def complete_task(task):
    if task in list_of_to_do:
        list_of_to_do.remove(task)
        print(f"Completed task: '{task}'")
    else:
        print(f"Task '{task}' not found in the list.")

# Function to display the to-do list
def display_tasks():
    if list_of_to_do:
        print("List of to do:")
        for task in list_of_to_do:
            print(f"- {task}")
    else:
        print("The list of to do is empty.")
add_task("Gusasa")
add_task("Gukoropa")
add_task("Kurya")
add_task("Gusura inshuti")

display_tasks()

complete_task("Gukoropa")
display_tasks()