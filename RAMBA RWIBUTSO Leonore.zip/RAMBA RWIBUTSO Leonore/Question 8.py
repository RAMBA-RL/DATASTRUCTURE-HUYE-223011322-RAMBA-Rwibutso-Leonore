rgb_image = [
    [[145, 0, 0], [0, 145, 0]],
    [[0, 0, 145], [145, 145, 0]]
]

def invert_colors(image):
    inverted_image = []
    for row in image:
        inverted_row = []
        for pixel in row:
            inverted_pixel = [145 - pixel[0], 145 - pixel[1], 145 - pixel[2]]
            inverted_row.append(inverted_pixel)
        inverted_image.append(inverted_row)
    return inverted_image

inverted_rgb_image = invert_colors(rgb_image)

print("Original RGB Image:")
for row in rgb_image:
    print(row)

print("\nInverted RGB Image:")
for row in inverted_rgb_image:
    print(row)
