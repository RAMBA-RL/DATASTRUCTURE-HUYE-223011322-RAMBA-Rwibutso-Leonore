list_of_ages = [29, 32, 34, 45, 10]
list_of_ages.sort()
print("Ascending order of ages():",list_of_ages)