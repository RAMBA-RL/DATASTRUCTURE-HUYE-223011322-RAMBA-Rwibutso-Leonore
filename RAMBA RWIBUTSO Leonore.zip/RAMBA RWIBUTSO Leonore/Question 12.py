list_of_shopping =['clothes','shoes', 'pillow', 'perfume' ,'jumper']
print(list_of_shopping)
list_of_shopping.remove('jumper')
print(list_of_shopping)

