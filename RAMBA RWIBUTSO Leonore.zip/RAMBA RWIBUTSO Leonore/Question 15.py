list_of_friends_1 = ['Jolly', 'Joana', 'Jonathan', 'Jonas']
list_of_friends_2 = ['Jimmy', 'James', 'Jaja', 'Jolly']

merged_friends_list = list (set(list_of_friends_1+list_of_friends_2))
print(merged_friends_list)