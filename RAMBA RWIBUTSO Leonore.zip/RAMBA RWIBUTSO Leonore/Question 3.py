price=[40,50,55,76,80,56,70]
max_price=max(price)
min_price=min(price)
print("Maximum stock price for the week:",max_price)
print("Minimum stock price for the week:",min_price)