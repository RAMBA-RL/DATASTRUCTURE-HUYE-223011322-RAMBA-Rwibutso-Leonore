city_temperatures= [
    [  # City 1
        [30, 34, 31],  # Day 1
        [29, 26, 30],  # Day 2
        [31, 22, 30],  # Day 3
        [30, 28, 28],  # Day 4
        [31, 30, 32],  # Day 5
        [29, 28, 33],  # Day 6
        [30, 32, 37]   # Day 7
    ],
    [  # City 2
        [23, 26, 27],  # Day 1
        [24, 23, 25],  # Day 2
        [26, 27, 25],  # Day 3
        [24, 28, 26],  # Day 4
        [22, 22, 24],  # Day 5
        [25, 24, 23],  # Day 6
        [26, 25, 24]   # Day 7
    ],
    [  # City 3
        [35, 34, 36],  # Day 1
        [35, 23, 34],  # Day 2
        [36, 35, 34],  # Day 3
        [35, 35, 33],  # Day 4
        [34, 36, 35],  # Day 5
        [33, 24, 36],  # Day 6
        [35, 33, 34]   # Day 7
    ],
    [  # City 4
        [20, 21, 22],  # Day 1
        [23, 22, 21],  # Day 2
        [22, 24, 21],  # Day 3
        [21, 20, 20],  # Day 4
        [22, 24, 23],  # Day 5
        [21, 22, 20],  # Day 6
        [20, 20, 22]   # Day 7
    ] 
]
def calculate_average_temperature(city_temperatures):
    averages = []
    for city in city_temperatures:
        city_average = sum(sum(day) for day in city) / (len(city) * len(city[0]))
        averages.append(city_average)
    return averages

average_temperatures = calculate_average_temperature(city_temperatures)
for i, avg_temp in enumerate(average_temperatures):
    print(f"Average temperature for City {i+1}: {avg_temp}")


