Temp_readings = [23, 33, 26, 36, 39, 24, 28]
print(Temp_readings)
print(f"Temperature readings of a city): ℃({Temp_readings}")