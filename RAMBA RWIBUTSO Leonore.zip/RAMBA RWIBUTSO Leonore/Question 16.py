# List of students: [Name, Age, Grade]
students = [
    ["Annet",21, 79],
    ["Brian", 13, 67],
    ["Charles", 15, 65],
    ["Anitha", 14, 70],
    ["Elie", 13, 68]
]
students_sorted_by_grade = sorted(students, key=lambda student: student[2])

for student in students_sorted_by_grade:
    print(student)