products = [
    ["Laptop", 1000, 10],
    ["Tablet", 800, 0],  
    ["Headsets", 150, 25],
    ["Airpods", 300, 0],     
    ["Keyboard", 50, 15],
    ["stands", 25, 30]
]
available_products = [product for product in products if product[2] > 0]
print("Available products:")
for product in available_products:
    print(f"Name: {product[0]}, Price: ${product[1]}, Stock: {product[2]}")