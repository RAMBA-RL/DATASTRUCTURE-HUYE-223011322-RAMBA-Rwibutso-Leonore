# LIST ANSWERS

participants = ["RAMBA", "NELLY", "NZIZA", "JOEL"]

print("Participants:", participants)

# Adding a new name to the list
new_participant = "CLAUDINE"
participants.append(new_participant)

# Display the updated list of attendees
print("Updated Participants:", participants)