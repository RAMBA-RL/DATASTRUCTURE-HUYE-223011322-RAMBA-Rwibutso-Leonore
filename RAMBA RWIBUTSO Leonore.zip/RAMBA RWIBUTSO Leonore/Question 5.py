numbers=[25,14,23,19,16,29,56,90,31]
even_count = 0
odd_count = 0

for number in numbers:
    if number % 2 == 0:
        even_count += 1
    else:
        odd_count += 1
print("Random Numbers:",numbers) 
print("Even numbers are equal to:", even_count)
print("Odd numbers are equal to:", odd_count)