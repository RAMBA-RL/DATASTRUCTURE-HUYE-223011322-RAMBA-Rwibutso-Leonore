rows, cols = 5, 7  
seating = [['O' for _ in range(cols)] for _ in range(rows)]
def reserve_seat(seating, row, col):
    if seating[row][col] == 'O':
        seating[row][col] = 'X'
        print(f"Seat ({row + 1}, {col + 1}) reserved.")
    else:
        print(f"Seat ({row + 1}, {col + 1}) is already reserved.")

reserve_seat(seating, 1, 3)  
reserve_seat(seating, 2, 5)  
reserve_seat(seating, 4, 1)  

def print_seating(seating):
    print("Seating arrangement:")
    for row in seating:
        print(" ".join(row))

print_seating(seating)