xmarks = [
    [79, 85, 93, 80,56],  # Marks for student 1
    [80, 77, 74, 91,87],  # Marks for student 2
    [60, 72, 85, 78,67],  # Marks for student 3
    [95, 89, 93, 96,89],  # Marks for student 4
    [77, 82, 79, 85,45]   # Marks for student 5
]

print("Marks of students in subjects:")
for marks in xmarks:
    print(marks)

# Calculate the total marks for each student
total_marks = []
for marks in xmarks:
    total = sum(marks)
    total_marks.append(total)

print("\nTotal marks of each student:")
for i, total in enumerate(total_marks, start=1):
    print(f"Student {i}: {total}")