expenses = [
    [1450, 1320, 1250, 1230, 1000, 1900],  # Rent expenses for 6 months
    [300, 380, 328, 350, 300, 340],  # Food expenses for 6 months
    [155, 160, 177, 180, 175, 169], # Utilities expenses for 6 months
    [450,230,340,200,145,302,340], # Entertainment expenses for 6 months
]
def calculate_average_expense(expense_list):
    averages = []
    for category_expenses in expense_list:
        category_average = sum(category_expenses) / len(category_expenses)
        averages.append(category_average)
    return averages
average_expenses = calculate_average_expense(expenses)

categories = ["Rent", "Food", "Utilities","Entertainment"]
for i, avg_expense in enumerate(average_expenses):
    print(f"Average monthly expense for {categories[i]}: ${avg_expense:.2f}")
