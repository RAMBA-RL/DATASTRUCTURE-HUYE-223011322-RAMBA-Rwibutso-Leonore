student_marks=[20,30,30,40,50]
student_marks.reverse()
print(student_marks)