sales = [
    [120, 113, 131, 90, 132, 115, 124],  # Product 1 sales for each day
    [74, 90, 85, 112, 100, 123, 90],     # Product 2 sales for each day
    [140, 163, 155, 185, 176, 169, 176]  # Product 3 sales for each day
]

products = ['Product 1', 'Product 2', 'Product 3']
days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

for i in range(len(sales)):
    print(f"{products[i]} sales for the week:")
    for j in range(len(sales[i])):
        print(f"{days[j]}: {sales[i][j]}")
    print()  
