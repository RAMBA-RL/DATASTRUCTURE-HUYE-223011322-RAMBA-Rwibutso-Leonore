scores = [
    [80, 78, 88],  # Scores of game 1
    [78, 67, 80],  # Scores of game 2
    [92, 76, 90]   # Scores of game 3
]

# Calculate the average scores for each player
average_scores = [sum(game_scores) / len(game_scores) for game_scores in scores]

# Find the winner based on the highest average score
winner_index = average_scores.index(max(average_scores))
winner_score = max(average_scores)

print(f"The winner is player {winner_index + 1} with an average score of {winner_score}.")



