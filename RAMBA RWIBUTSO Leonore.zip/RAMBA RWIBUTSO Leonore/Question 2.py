Daily_sales=[100,120,230,200,145,160,180]
Total_sales=sum(Daily_sales)
average_sales=Total_sales/7
print("The average daily sales over a week is:",average_sales)